# Excel Wilayah (POC)

Upload Excel berisi kolom `latitude` & `longitude` → dapat Provinsi, Kota/Kab, Kecamatan, Kelurahan/Desa
dari `indoadmin2024.gpkg`.

## Jalankan

```bash
docker compose up -d --build
```

Buka http://localhost:3000 lalu upload `contoh.xlsx`.
Pertama kali jalan, service `importer` memasukkan geopackage ke PostGIS (±1-2 menit).
Selanjutnya dilewati karena tabel sudah ada.

## Alur

1. **db** – PostgreSQL + PostGIS.
2. **importer** – `ogr2ogr` (GDAL) memindahkan layer `indoadmin` ke tabel `wilayah` + index spasial GiST.
3. **app** – Express: baca Excel (exceljs) → satu query `ST_Intersects` titik vs poligon → JSON / Excel.

## API

- `POST /api/lookup` (form-data `file`) → JSON
- `POST /api/lookup?format=xlsx` → file Excel hasil

## Reset

```bash
docker compose down -v
```
