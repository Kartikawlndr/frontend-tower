// Membuat contoh file Excel berisi koordinat untuk demo
const ExcelJS = require('exceljs');

const points = [
  [-6.175392, 106.827153], // Monas, Jakarta
  [-6.914744, 107.609810], // Bandung
  [-7.250445, 112.768845], // Surabaya
  [-7.795580, 110.369490], // Yogyakarta
  [3.595196, 98.672223],   // Medan
  [-8.650000, 115.216667], // Denpasar
  [-5.147665, 119.432732], // Makassar
  [-2.533000, 140.717000], // Jayapura
  [-6.000000, 105.000000], // Laut (tidak ada wilayah)
];

const wb = new ExcelJS.Workbook();
const ws = wb.addWorksheet('Data');
ws.addRow(['latitude', 'longitude']);
points.forEach((p) => ws.addRow(p));
wb.xlsx.writeFile(process.argv[2] || 'contoh.xlsx').then(() => console.log('contoh.xlsx dibuat'));
