const express = require('express');
const multer = require('multer');
const ExcelJS = require('exceljs');
const { Pool } = require('pg');
const path = require('path');

const app = express();
const upload = multer({ storage: multer.memoryStorage() });
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

app.use(express.static(path.join(__dirname, 'public')));

// Baca Excel: cari kolom latitude & longitude dari header, fallback ke kolom A & B
async function readCoordinates(buffer) {
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(buffer);
  const sheet = workbook.worksheets[0];

  let latCol = 1;
  let lonCol = 2;
  sheet.getRow(1).eachCell((cell, col) => {
    const name = String(cell.value).toLowerCase().trim();
    if (name.startsWith('lat')) latCol = col;
    if (['lon', 'lng', 'long', 'longitude'].includes(name)) lonCol = col;
  });

  const rows = [];
  sheet.eachRow((row, rowNumber) => {
    if (rowNumber === 1) return; // header
    const lat = parseFloat(row.getCell(latCol).value);
    const lon = parseFloat(row.getCell(lonCol).value);
    rows.push({ lat, lon });
  });
  return rows;
}

// Satu query untuk semua titik: unnest array lat/lon lalu cari poligon yang memuat titik
async function lookup(rows) {
  const sql = `
    SELECT p.idx, w.kdepum, w.province, w.district, w.subdistric, w.village
    FROM unnest($1::float8[], $2::float8[]) WITH ORDINALITY AS p(lat, lon, idx)
    LEFT JOIN LATERAL (
      SELECT kdepum, province, district, subdistric, village
      FROM wilayah
      WHERE ST_Intersects(geom, ST_SetSRID(ST_MakePoint(p.lon, p.lat), 4326))
      LIMIT 1
    ) w ON true
    ORDER BY p.idx`;
  const { rows: result } = await pool.query(sql, [
    rows.map((r) => (Number.isFinite(r.lat) ? r.lat : null)),
    rows.map((r) => (Number.isFinite(r.lon) ? r.lon : null)),
  ]);

  return rows.map((r, i) => ({
    latitude: r.lat,
    longitude: r.lon,
    kode: result[i].kdepum,
    provinsi: result[i].province,
    kota: result[i].district,
    kecamatan: result[i].subdistric,
    kelurahan: result[i].village,
  }));
}

app.post('/api/lookup', upload.single('file'), async (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'File Excel wajib diupload' });

  try {
    const coords = await readCoordinates(req.file.buffer);
    const data = await lookup(coords);

    if (req.query.format !== 'xlsx') return res.json(data);

    // Kembalikan sebagai file Excel
    const out = new ExcelJS.Workbook();
    const sheet = out.addWorksheet('Hasil');
    sheet.columns = Object.keys(data[0] || { latitude: 0 }).map((key) => ({ header: key, key, width: 20 }));
    sheet.addRows(data);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename="hasil-wilayah.xlsx"');
    await out.xlsx.write(res);
    res.end();
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`App jalan di http://localhost:${port}`));
