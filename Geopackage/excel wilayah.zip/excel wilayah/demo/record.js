// Rekam video demo aplikasi dengan Playwright: caption per langkah + kursor palsu
const { chromium } = require('playwright');
const ExcelJS = require('exceljs');
const fs = require('fs');

const BASE_URL = process.env.BASE_URL || 'http://localhost:3000';
const WORK = process.env.WORK || '/work';
const SIZE = { width: 1280, height: 720 };

// Disuntikkan ke setiap halaman: kursor yang mengikuti mouse dan bar caption di bawah
const overlay = () => {
  window.addEventListener('DOMContentLoaded', () => {
    const style = document.createElement('style');
    style.textContent = `
      #demo-cursor { position: fixed; z-index: 99999; width: 22px; height: 22px; margin: -4px 0 0 -4px;
        pointer-events: none; transition: transform .1s; }
      #demo-cursor.down { transform: scale(.8); }
      #demo-caption { position: fixed; z-index: 99998; left: 50%; bottom: 28px; transform: translateX(-50%);
        max-width: 1000px; padding: 14px 24px; border-radius: 10px; background: rgba(16,24,29,.92);
        color: #fff; font: 600 22px/1.35 "Segoe UI", system-ui, sans-serif; text-align: center;
        box-shadow: 0 6px 24px rgba(0,0,0,.25); transition: opacity .3s; }
      #demo-caption small { display: block; font: 600 13px/1.4 Consolas, monospace; color: #4cc3b0;
        letter-spacing: .08em; text-transform: uppercase; margin-bottom: 4px; }
      #demo-caption:empty { opacity: 0; }
      body { padding-bottom: 280px !important; }
      .demo-highlight { outline: 3px solid #4cc3b0 !important; outline-offset: 4px; border-radius: 4px; }
    `;
    document.head.appendChild(style);

    const cursor = document.createElement('div');
    cursor.id = 'demo-cursor';
    cursor.innerHTML = '<svg viewBox="0 0 24 24" width="22" height="22"><path d="M3 2l7 19 3-8 8-3z" fill="#111" stroke="#fff" stroke-width="1.5"/></svg>';
    document.body.appendChild(cursor);
    document.addEventListener('mousemove', (e) => { cursor.style.left = e.clientX + 'px'; cursor.style.top = e.clientY + 'px'; });
    document.addEventListener('mousedown', () => cursor.classList.add('down'));
    document.addEventListener('mouseup', () => cursor.classList.remove('down'));

    const caption = document.createElement('div');
    caption.id = 'demo-caption';
    document.body.appendChild(caption);
  });
};

const wait = (ms) => new Promise((r) => setTimeout(r, ms));

async function caption(page, step, text, ms = 2500) {
  await page.evaluate(([s, t]) => {
    document.getElementById('demo-caption').innerHTML = t ? `<small>${s}</small>${t}` : '';
  }, [step, text]);
  await wait(ms);
}

async function moveTo(page, selector) {
  const box = await page.locator(selector).first().boundingBox();
  await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2, { steps: 25 });
  await wait(300);
}

async function highlight(page, selector, on = true) {
  await page.locator(selector).first().evaluate((el, on) => el.classList.toggle('demo-highlight', on), on);
}

// Tampilkan isi file .xlsx dalam tampilan mirip Excel (dibaca dari file aslinya)
async function showExcel(page, filePath, fileName, newCols = []) {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.readFile(filePath);
  const ws = wb.worksheets[0];
  const colCount = ws.columnCount;
  const letters = Array.from({ length: colCount }, (_, i) => String.fromCharCode(65 + i));

  const rows = [];
  ws.eachRow((row, n) => {
    const cells = letters.map((_, i) => {
      const v = row.getCell(i + 1).value;
      const cls = [n === 1 ? 'head' : '', newCols.includes(i + 1) ? 'new' : '', typeof v === 'number' ? 'num' : ''].join(' ');
      return `<td class="${cls}">${v ?? ''}</td>`;
    });
    rows.push(`<tr><th>${n}</th>${cells.join('')}</tr>`);
  });

  const html = `<!doctype html><meta charset="utf-8"><style>
    body { margin: 0; background: #e8e8e8; font: 14px Calibri, "Segoe UI", sans-serif; }
    .bar { background: #217346; color: #fff; padding: 10px 20px; font-size: 15px; display: flex; gap: 12px; align-items: center; }
    .bar b { background: #fff; color: #217346; border-radius: 3px; padding: 0 6px; font-size: 13px; }
    .fx { background: #fff; border-bottom: 1px solid #d0d0d0; padding: 6px 20px; color: #555; font-size: 13px; }
    .fx span { display: inline-block; width: 60px; border-right: 1px solid #d0d0d0; margin-right: 12px; }
    table { border-collapse: collapse; background: #fff; }
    th { background: #f3f3f3; color: #666; font-weight: 400; border: 1px solid #d4d4d4; padding: 3px 10px; min-width: 28px; }
    td { border: 1px solid #e2e2e2; padding: 4px 10px; white-space: nowrap; min-width: 90px; }
    td.num { text-align: right; }
    td.head { font-weight: 700; }
    td.new { background: #e2f0d9; }
    .tab { display: inline-block; margin: 0 0 0 46px; background: #fff; border-bottom: 3px solid #217346; padding: 6px 18px; color: #217346; font-weight: 700; }
  </style>
  <div class="bar"><b>X</b>${fileName} - Excel</div>
  <div class="fx"><span>A1</span>${ws.getCell('A1').value}</div>
  <table><tr><th></th>${letters.map((l) => `<th>${l}</th>`).join('')}</tr>${rows.join('')}</table>
  <div class="tab">${ws.name}</div>`;

  const tmp = `/tmp/excel-${fileName}.html`;
  fs.writeFileSync(tmp, html);
  await page.goto(`file://${tmp}`);
  await page.mouse.move(1200, 650);
}

(async () => {
  const browser = await chromium.launch();
  const context = await browser.newContext({
    viewport: SIZE,
    recordVideo: { dir: '/tmp/video', size: SIZE },
    acceptDownloads: true,
  });
  await context.addInitScript(overlay);
  const page = await context.newPage();

  // Kartu judul
  await page.setContent(`
    <body style="margin:0;height:100vh;display:flex;flex-direction:column;justify-content:center;padding:0 120px;
      background:#10181d;color:#e4ecef;font-family:'Segoe UI',system-ui,sans-serif">
      <div style="font:600 16px Consolas,monospace;color:#4cc3b0;letter-spacing:.1em">DEMO POC · INTERNSHIP</div>
      <h1 style="font-size:64px;margin:16px 0">Excel Wilayah</h1>
      <p style="font-size:26px;color:#9db0ba;max-width:900px;margin:0">
        Upload Excel berisi latitude &amp; longitude, dapatkan provinsi, kota, kecamatan, dan kelurahan.</p>
      <p style="font:18px Consolas,monospace;color:#9db0ba;margin-top:40px">Node.js · Express · PostgreSQL + PostGIS · Docker</p>
    </body>`);
  await page.mouse.move(640, 650);
  await wait(4000);

  // File input
  await showExcel(page, `${WORK}/contoh.xlsx`, 'contoh.xlsx');
  await caption(page, 'File input', 'contoh.xlsx: hanya berisi 2 kolom, latitude dan longitude', 4000);
  await caption(page, 'File input', 'Setiap baris adalah satu titik koordinat yang ingin dicari wilayahnya', 3500);

  // 1. Buka aplikasi
  await page.goto(BASE_URL);
  await page.mouse.move(640, 400);
  await caption(page, 'Langkah 1', 'Buka aplikasi di http://localhost:3000', 3000);

  // 2. Pilih file
  await caption(page, 'Langkah 2', 'Siapkan Excel dengan kolom latitude dan longitude (contoh.xlsx, 9 titik)', 3000);
  await moveTo(page, 'input[type=file]');
  const [chooser] = await Promise.all([page.waitForEvent('filechooser'), page.locator('input[type=file]').click()]);
  await chooser.setFiles(`${WORK}/contoh.xlsx`);
  await highlight(page, 'input[type=file]');
  await caption(page, 'Langkah 2', 'File dipilih: contoh.xlsx', 2500);
  await highlight(page, 'input[type=file]', false);

  // 3. Proses
  await moveTo(page, 'button[type=submit]');
  await caption(page, 'Langkah 3', 'Klik Proses: file dikirim ke server, semua titik dicari dalam satu query PostGIS', 3000);
  await page.click('button[type=submit]');
  await page.waitForSelector('#result tr:nth-child(2)');
  await page.mouse.move(900, 300, { steps: 20 });
  await caption(page, 'Langkah 3', 'Hasil keluar kurang dari 1 detik', 3000);

  // 4. Jelaskan hasil
  await highlight(page, '#result tr:nth-child(2)');
  await caption(page, 'Hasil', 'Monas (-6.175, 106.827) → DKI Jakarta · Jakarta Pusat · Gambir · Gambir', 4000);
  await highlight(page, '#result tr:nth-child(2)', false);
  await highlight(page, '#result tr:last-child');
  await caption(page, 'Hasil', 'Titik di laut tidak masuk poligon desa mana pun, jadi kolomnya kosong', 4000);
  await highlight(page, '#result tr:last-child', false);

  // 5. Download
  await moveTo(page, '#download');
  await caption(page, 'Langkah 4', 'Klik Download Excel untuk mendapatkan hasil dalam bentuk .xlsx', 2500);
  const [download] = await Promise.all([page.waitForEvent('download'), page.click('#download')]);
  await download.saveAs('/tmp/hasil-wilayah.xlsx');
  await caption(page, 'Langkah 4', `File ${download.suggestedFilename()} berhasil diunduh`, 3000);

  // File output
  await showExcel(page, '/tmp/hasil-wilayah.xlsx', download.suggestedFilename(), [3, 4, 5, 6, 7]);
  await caption(page, 'File output', 'hasil-wilayah.xlsx: koordinat yang sama, ditambah kolom wilayah (warna hijau)', 4500);
  await caption(page, 'File output', 'kode, provinsi, kota, kecamatan, kelurahan didapat dari PostGIS', 4000);

  // 6. Cara kerjanya: halaman alur
  await page.goto(`file://${WORK}/docs/flow.html`);
  await page.waitForLoadState('networkidle');
  await page.mouse.move(1200, 650);
  await caption(page, 'Cara kerja', 'Bagaimana Excel bisa mendapat data wilayah?', 4000);
  for (const [sel, text, ms] of [
    ['.diagram', 'Alurnya tiga langkah: GeoPackage → PostGIS ← Excel, lalu hasil dikeluarkan', 5000],
    ['.concept:nth-of-type(1)', '1. GeoPackage berisi poligon desa se-Indonesia, diimpor ke PostGIS sekali saja', 5500],
    ['.concept:nth-of-type(2)', '2. Setiap koordinat dicek: titik ini jatuh di poligon desa yang mana?', 6000],
    ['.concept:nth-of-type(3)', '3. Hasilnya ditampilkan di HTML, diunduh sebagai Excel, atau disimpan ke database', 5500],
    ['.example', 'Contoh: koordinat Monas → DKI Jakarta · Jakarta Pusat · Gambir · Gambir', 5000],
  ]) {
    await page.locator(sel).evaluate((el) => window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 40, behavior: 'smooth' }));
    await caption(page, 'Cara kerja', text, ms);
  }
  await caption(page, 'Selesai', 'Silakan coba sendiri: docker compose up -d --build', 3500);

  const video = page.video();
  await context.close();
  fs.mkdirSync(`${WORK}/demo/output`, { recursive: true });
  await video.saveAs(`${WORK}/demo/output/demo.webm`);
  await browser.close();
  console.log('Video tersimpan di demo/output/demo.webm');
})();
