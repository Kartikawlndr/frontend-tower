#!/bin/sh
set -e

PG="PG:host=db user=postgres password=postgres dbname=wilayah"

if ogrinfo "$PG" -sql "SELECT 1 FROM wilayah LIMIT 1" > /dev/null 2>&1; then
  echo "Tabel wilayah sudah ada, import dilewati."
  exit 0
fi

echo "Import geopackage ke PostGIS... (beberapa menit)"
ogr2ogr -f PostgreSQL "$PG" /data/indoadmin2024.gpkg indoadmin \
  -nln wilayah \
  -nlt MULTIPOLYGON \
  -lco GEOMETRY_NAME=geom \
  -lco SPATIAL_INDEX=GIST \
  -select KDEPUM,Province,District,Subdistric,Village \
  -progress

echo "Import selesai."
